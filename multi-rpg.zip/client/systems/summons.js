// Summoned beast lifecycle: own summon (spawn/destroy) and other players' summons (network sync).
import Enemy from '../entities/Enemy.js';
import SummonedBeast from '../entities/SummonedBeast.js';
import { applySkillEffect } from './skillEffects.js';
import { getLevelDiffMultiplier } from '../utils/levelScaling.js';

export function isSummonSkill(skillId) {
    return skillId === 'summon' || skillId === 'mega_summon' || skillId === 'demon_lord_summon';
}

/**
 * Spawn the local player's summon (replacing any existing one) and notify the server.
 */
export function spawnSummon(scene, player, summonType = 'summon') {
    if (scene.activeSummon && scene.activeSummon.active) {
        destroySummon(scene, scene.activeSummon);
    }

    const summonX = player.x + (player.facingDirection === -1 ? -50 : 50);
    const summonY = player.y;

    const skillLevel = player.stats.skillLevels?.[summonType] || 1;
    const summon = new SummonedBeast(scene, summonX, summonY, player, summonType, skillLevel);
    scene.activeSummon = summon;

    // このSummonのために作ったColliderをここに集めておき、召喚獣が消滅するときに
    // 必ず破棄する（destroySummon参照）。
    // 修正前はここで敵ごとに登録したoverlapを一切破棄していなかったため、
    // 「召喚→消滅→再召喚」を繰り返すたびに古いColliderが物理ワールドに残り続け、
    // 敵を倒しても当たり判定コストが減らず、徐々に重くなるバグの原因になっていた。
    summon._colliders = [];

    // Contact damage from enemies that already exist (new enemies are handled in spawnEnemyFromServer)
    const enemies = scene.children.list.filter(child => child instanceof Enemy && child.active);
    enemies.forEach(enemy => {
        if (enemy.active) {
            const collider = scene.physics.add.overlap(summon, enemy, () => {
                const now = scene.time.now;
                if (!summon.lastHitTime || now - summon.lastHitTime > 1000) {
                    const levelMult = getLevelDiffMultiplier(enemy.level, summon.level ?? 1);
                    summon.takeDamage(Math.max(1, Math.ceil(enemy.atk * levelMult)));
                    if (summon) summon.lastHitTime = now;
                }
            });
            summon._colliders.push(collider);
        }
    });

    applySkillEffect(scene, 'summon', player);

    if (scene.notificationUI) {
        scene.notificationUI.show('召喚獣を呼び出した！', 'success');
    }

    if (scene.networkManager) {
        scene.networkManager.sendSummonUpdate({
            type: 'spawn',
            isMega: summon.isMega,
            x: summon.x,
            y: summon.y
        });
    }
}

/**
 * Remove the local player's summon, start the summon cooldown and notify the server.
 */
export function destroySummon(scene, summon) {
    if (!summon || !summon.active) return;

    // Cooldown starts when the summon disappears
    if (scene.player && scene.player.skillCooldowns) {
        const skillId = summon.isMega ? 'mega_summon' : 'summon';
        scene.player.skillCooldowns[skillId] = Date.now();
    }

    const fadeCircle = scene.add.circle(summon.x, summon.y, 20, 0x9370db, 0.5);
    scene.tweens.add({
        targets: fadeCircle,
        scale: 2,
        alpha: 0,
        duration: 500,
        onComplete: () => fadeCircle.destroy()
    });

    // このSummonに紐づく全Colliderを破棄してから消す（物理ワールドへの残留を防ぐ）
    if (summon._colliders) {
        summon._colliders.forEach(c => { if (c && c.world) c.destroy(); });
        summon._colliders.length = 0;
    }

    if (summon.hpBar) summon.hpBar.destroy();
    if (summon.hpBarBg) summon.hpBarBg.destroy();
    if (summon.preDestroy) summon.preDestroy();
    summon.destroy();

    if (scene.activeSummon === summon) {
        scene.activeSummon = null;
        if (scene.networkManager) {
            scene.networkManager.sendSummonUpdate({ type: 'despawn' });
        }
    }
}

/**
 * Apply a summon event received from the server for another player.
 * @param {{id: string, type: 'spawn'|'move'|'despawn', x?: number, y?: number, isMega?: boolean}} data
 */
export function handleSummonUpdate(scene, data) {
    if (data.id === scene.networkManager.getPlayerId()) return; // ignore our own echo

    if (data.type === 'spawn') {
        const owner = scene.networkManager.getOtherPlayers()[data.id];
        if (owner) {
            if (scene.otherSummons[data.id]) {
                scene.otherSummons[data.id].destroy();
            }
            const summon = new SummonedBeast(scene, data.x, data.y, owner, data.isMega);
            scene.otherSummons[data.id] = summon;
        }
    } else if (data.type === 'move') {
        const summon = scene.otherSummons[data.id];
        if (summon && summon.active) {
            // Simple movement toward the reported position (no interpolation yet)
            scene.physics.moveTo(summon, data.x, data.y, 200);

            // Snap when close enough
            if (Phaser.Math.Distance.Between(summon.x, summon.y, data.x, data.y) < 10) {
                summon.body.reset(data.x, data.y);
            }
        }
    } else if (data.type === 'despawn') {
        const summon = scene.otherSummons[data.id];
        if (summon) {
            summon.destroy();
            delete scene.otherSummons[data.id];
        }
    }
}
